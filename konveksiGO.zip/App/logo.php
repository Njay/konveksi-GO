<a href="index.php" class="brand-link">
      <img src="dist/img/k-logo.jpg" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">Koveksi GO</span>
    </a>