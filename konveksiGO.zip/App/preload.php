<div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__wobble" src="dist/img/k-logo.jpg" alt="AdminLTELogo" height="60" width="60">
  </div>